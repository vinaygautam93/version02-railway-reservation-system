package com.casestudy.controller;

public class AdminControllerTest {
}
