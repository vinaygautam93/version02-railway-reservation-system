package com.casestudy.service;

import com.casestudy.model.AdminModel;
import com.casestudy.model.AuthenticationRequest;
import com.casestudy.model.AuthenticationResponse;
import com.casestudy.repository.AdminRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private AdminRepository adminrepo;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserInfoService userInfoService;

    @Autowired
    private JwtUtil jwtUtil;

    public ResponseEntity<AuthenticationResponse> register(AuthenticationRequest request) {
        try {
            AdminModel admin = new AdminModel();
            admin.setUsername(request.getUsername());
            admin.setPassword(request.getPassword());
            adminrepo.save(admin);

            return new ResponseEntity<>(
                    new AuthenticationResponse(request.getUsername() + " registered Successfully"), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new AuthenticationResponse("Registration Failed"), HttpStatus.OK);
        }
    }

    public ResponseEntity<AuthenticationResponse> authenticate(AuthenticationRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
        } catch (Exception e) {
            return ResponseEntity.ok(new AuthenticationResponse("no"));
        }

        UserDetails userDetails = userInfoService.loadUserByUsername(request.getUsername());
        String jwt = jwtUtil.generateToken(userDetails);

        return ResponseEntity.ok(new AuthenticationResponse(jwt));
    }

    public String registerRawAdmin(AdminModel adminModel) {
        adminrepo.save(adminModel);
        return "User with Id: " + adminModel.getId() + " have been Registered Successfully";
    }
}